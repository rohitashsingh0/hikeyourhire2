import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { BiBriefcaseAlt2 } from 'react-icons/bi';
import { BsStars } from 'react-icons/bs';
import { MdOutlineKeyboardArrowDown } from 'react-icons/md';

import CustomButton from '../../components/JobBoardComponents/CustomButton';
import JobCard from '../../components/JobBoardComponents/JobCard';
import ListBox from '../../components/JobBoardComponents/ListBox';
import { experience, jobTypes, jobs } from '../../utils/data';

const JobListings = () => {
  const [sort, setSort] = useState('Newest');
  const [page, setPage] = useState(1);
  const [numPage, setNumPage] = useState(1);
  const [recordCount, setRecordCount] = useState(0);
  const [data, setData] = useState([]);

  const [searchQuery, setSearchQuery] = useState('');
  const [jobLocation, setJobLocation] = useState('');
  const [filterJobTypes, setFilterJobTypes] = useState([]);
  const [filterExp, setFilterExp] = useState([]);

  const [isFetching, setIsFetching] = useState(false);

  const location = useLocation();
  const navigate = useNavigate();

  const filterJobs = (val) => {
    if (filterJobTypes?.includes(val)) {
      setFilterJobTypes(filterJobTypes.filter((el) => el != val));
    } else {
      setFilterJobTypes([...filterJobTypes, val]);
    }
  };

  //   const filterExperience = async (e) => {
  //     setFilterExp(e);
  //   };

  return (
    <div>
      <div className="container mx-auto flex gap-6 2xl:gap-10 md:px-5 py-0 md:py-6 bg-[#f7fdfd]">
        <div className="w-full px-5 md:px-0">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm md:text-base">
              Shwoing: <span className="font-semibold">1,902</span> Jobs
              Available
            </p>

            <div className="flex flex-col md:flex-row gap-0 md:gap-2 md:items-center">
              <p className="text-sm md:text-base">Sort By:</p>

              <ListBox sort={sort} setSort={setSort} />
            </div>
          </div>

          <div className="w-full flex flex-wrap gap-4">
            {jobs.map((job, index) => (
              <JobCard job={job} key={index} />
            ))}
          </div>

          {numPage > page && !isFetching && (
            <div className="w-full flex items-center justify-center pt-16">
              <CustomButton
                title="Load More"
                containerStyles={`text-blue-600 py-1.5 px-5 focus:outline-none hover:bg-blue-700 hover:text-white rounded-full text-base border border-blue-600`}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobListings;
