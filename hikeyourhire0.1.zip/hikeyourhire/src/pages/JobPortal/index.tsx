import JobLayout from '../../layout/JobLayout';

const JobPortal = () => {
  return (
    <JobLayout>
      <div>JobPortal</div>
    </JobLayout>
  );
};

export default JobPortal;
