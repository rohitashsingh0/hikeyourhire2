import React from 'react';
import ProfileLayout from '../../layout/ProfileLayout';

const UserProfile = () => {
  return (
    <>
      <ProfileLayout>
        <h1>User Profile Layout</h1>
      </ProfileLayout>
    </>
  );
};

export default UserProfile;
