import React from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import ChartOne from '../../components/AdminComponents/Charts/ChartOne';
import ChartTwo from '../../components/AdminComponents/Charts/ChartTwo';
import TableOne from '../../components/AdminComponents/Tables/TableOne';
import DefaultLayout from '../../layout/DefaultLayout';
import Assets from '/assets/admin/dashboard/Asset.svg';

const Dashboard: React.FC = () => {
  return (
    <DefaultLayout>
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4  md:gap-6  2xl:gap-7.5">
        {/* big column */}
        <div className="col-span-12 md:col-span-8 rounded-2xl border border-stroke bg-[#04ADE6] px-5 pt-7.5 pb-5 shadow-default dark:border-strokedark dark:bg-boxdark sm:px-7.5">
          <div className="flex flex-col sm:flex-row justify-between items-center text-center  sm:text-start gap-3 my-auto">
            <div className="flex-1">
              <p className="font-base text-lg text-primary text-white">
                Hello John!
              </p>
              <p className="text-xl font-medium text-white">
                You have 9 new applicants today!
              </p>
              <p className="text-xl font-semibold text-white">
                Review applicants
              </p>
            </div>
            <div className="flex-none">
              <img src={Assets} alt="assets image" />
            </div>
          </div>
        </div>
        {/* small column */}
        <div className="col-span-12 md:col-span-4 rounded-2xl border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
          <Calendar className="w-full border-0 rounded-2xl p-2" />
        </div>
      </div>
      <div className="mt-4 grid grid-cols-12 gap-4 md:mt-6 md:gap-6 2xl:mt-7.5 2xl:gap-7.5">
        <ChartOne />
        <ChartTwo />
        <div className="col-span-12">
          <TableOne />
        </div>
      </div>
    </DefaultLayout>
  );
};

export default Dashboard;
