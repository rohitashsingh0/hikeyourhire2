import { Link } from 'react-router-dom';
import { MdAccessTimeFilled } from 'react-icons/md';
import { IoLocationSharp } from 'react-icons/io5';
import { FaArrowRightLong } from 'react-icons/fa6';

interface cardDataType {
  imgSrc: string;
  title: string;
  category: string;
  jobType: string;
  location: string;
}

const cardData: cardDataType[] = [
  {
    imgSrc: '/assets/admin/featured/featured.svg',
    title: 'Customer Service',
    category: 'Sales, Service, & Support',
    jobType: 'Full Time',
    location: 'Delhi',
  },
  {
    imgSrc: '/assets/admin/featured/featured2.svg',
    title: 'Software Engineer',
    category: 'Engineering & Tech',
    jobType: 'Full Time',
    location: 'Noida',
  },
  {
    imgSrc: '/assets/admin/featured/featured3.svg',
    title: 'HR Director',
    category: 'People',
    jobType: 'Part Time',
    location: 'Canada',
  },
];

const Featured = () => {
  return (
    <div className="mx-auto max-w-7xl py-16 px-6">
      <div className="flex justify-between items-center pb-8 px-2">
        <h1 className="text-2xl font-semibold text-black">
          Latest featured jobs
        </h1>
        <p className=" text-base font-semibold text-black">
          <Link to="/jobs" className="flex items-center">
            <span className="mr-4">Explore more</span> <FaArrowRightLong />
          </Link>
        </p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-y-20 gap-x-5">
        {cardData.map((items, i) => (
          <div
            className="flex flex-col justify-center items-start  bg-white rounded-3xl shadow-xl"
            key={i}
          >
            <div className=" p-2 rounded-lg w-full">
              <img src={items.imgSrc} alt={items.imgSrc} className="w-full" />
            </div>
            <div className="p-6 w-full">
              <h2 className="text-lg lg:text-xl text-black font-semibold mt-1">
                {items.title}
              </h2>
              <h2 className="text-sm lg:text-base text-black font-light  mt-1">
                {items.category}
              </h2>
              <h3 className="text-sm lg:text-base flex items-center text-black font-light  mt-4">
                <MdAccessTimeFilled className="mr-2 " />{' '}
                <span>{items.jobType}</span>
              </h3>
              <p className="text-sm lg:text-base flex items-center text-black font-light  mb-6">
                <IoLocationSharp className="mr-2" />{' '}
                <span>{items.location}</span>
              </p>
              <Link
                to="/jobs"
                className="bg-[#04ADE6] w-full p-2 text-white rounded mt-3"
              >
                <button className="w-full">Apply NOw</button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Featured;
