import { useEffect, useState } from 'react';
import { Route, Routes, useLocation } from 'react-router-dom';

import Loader from './common/Loader';
import PageTitle from './components/AdminComponents/PageTitle';
import SignIn from './pages/Authentication/SignIn';
import SignUp from './pages/Authentication/SignUp';
import Calendar from './pages/Calendar';
import Chart from './pages/Chart';
import Dashboard from './pages/Dashboard/Dashboard';
import FormElements from './pages/Form/FormElements';
import FormLayout from './pages/Form/FormLayout';
import Profile from './pages/Profile';
import Settings from './pages/Dashboard/Settings';
import Alerts from './pages/UiElements/Alerts';
import Buttons from './pages/UiElements/Buttons';
import UserPanel from './pages/UserPanel';
import JobPortal from './pages/JobPortal';
import UserProfile from './pages/UserProfile';
import Login from './pages/JobPortal/authentication/Login';
import Register from './pages/JobPortal/authentication/Register';
import Registration_Success from './pages/JobPortal/authentication/Registration_Success';
import Otp from './pages/JobPortal/authentication/Otp';
import ForgotPassword from './pages/JobPortal/authentication/ForgotPassword';
import JobDetail from './pages/JobPortal/JobDetail';
import Admins from './pages/Dashboard/Admins';
import Users from './pages/Dashboard/Users';
import Help from './pages/Help';

function App() {
  const [loading, setLoading] = useState<boolean>(true);
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    setTimeout(() => setLoading(false), 1000);
  }, []);

  return loading ? (
    <Loader />
  ) : (
    <>
      <Routes>
        <Route
          index
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <UserPanel />
            </>
          }
        />
        <Route
          path="/jobs"
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <JobPortal />
            </>
          }
        />
        <Route
          path="/job-detail/:id"
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <JobDetail />
            </>
          }
        />
        <Route
          path="/login"
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <Login />
            </>
          }
        />
        <Route
          path="/register"
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <Register />
            </>
          }
        />
        <Route
          path="/register-success"
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <Registration_Success />
            </>
          }
        />
        <Route
          path="/forgot-password"
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <ForgotPassword />
            </>
          }
        />
        <Route
          path="/otp"
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <Otp />
            </>
          }
        />
        <Route
          path="/profile"
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <UserProfile />
            </>
          }
        />
        <Route
          path="/dashboard"
          element={
            <>
              <PageTitle title="Hikeyourhire Dashboard" />
              <Dashboard />
            </>
          }
        />
        <Route
          path="/calendar"
          element={
            <>
              <PageTitle title="Calendar" />
              <Calendar />
            </>
          }
        />
        <Route
          path="/user-profile"
          element={
            <>
              <PageTitle title="Profile" />
              <Profile />
            </>
          }
        />
        <Route
          path="/forms/form-elements"
          element={
            <>
              <PageTitle title="Form Elements" />
              <FormElements />
            </>
          }
        />
        <Route
          path="/forms/form-layout"
          element={
            <>
              <PageTitle title="Form Layout" />
              <FormLayout />
            </>
          }
        />
        <Route
          path="/users"
          element={
            <>
              <PageTitle title="Tables" />
              <Users />
            </>
          }
        />
        <Route
          path="/admins"
          element={
            <>
              <PageTitle title="Admins" />
              <Admins />
            </>
          }
        />
        <Route
          path="/settings"
          element={
            <>
              <PageTitle title="Settings" />
              <Settings />
            </>
          }
        />
        <Route
          path="/chart"
          element={
            <>
              <PageTitle title="Basic Chart" />
              <Chart />
            </>
          }
        />
        <Route
          path="/ui/alerts"
          element={
            <>
              <PageTitle title="Alerts" />
              <Alerts />
            </>
          }
        />
        <Route
          path="/ui/buttons"
          element={
            <>
              <PageTitle title="Buttons" />
              <Buttons />
            </>
          }
        />
        <Route
          path="/auth/signin"
          element={
            <>
              <PageTitle title="Signin" />
              <SignIn />
            </>
          }
        />
        <Route
          path="/auth/signup"
          element={
            <>
              <PageTitle title="Signup" />
              <SignUp />
            </>
          }
        />
        <Route
          path="/help"
          element={
            <>
              <PageTitle title="Help" />
              <Help />
            </>
          }
        />
      </Routes>
    </>
  );
}

export default App;
