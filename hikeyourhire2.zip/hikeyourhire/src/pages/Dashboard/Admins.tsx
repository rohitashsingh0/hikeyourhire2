import Breadcrumb from '../../components/AdminComponents/Breadcrumbs/Breadcrumb';
import AdminTable from '../../components/AdminComponents/Tables/AdminTable';
import DefaultLayout from '../../layout/DefaultLayout';

const Admins = () => {
  return (
    <DefaultLayout>
      <Breadcrumb pageName="Admins" />

      <div className="flex flex-col gap-10">
        <AdminTable />
      </div>
    </DefaultLayout>
  );
};

export default Admins;
