import { useEffect, useState } from 'react';
import moment from 'moment';
import { AiOutlineFilePdf, AiOutlineSafetyCertificate } from 'react-icons/ai';
import { Link, useParams } from 'react-router-dom';
import { jobs } from '../../utils/data';
import JobCard from '../../components/JobBoardComponents/JobCard';
import CustomButton from '../../components/JobBoardComponents/CustomButton';
import JobLayout from '../../layout/JobLayout';
import { ImCheckmark } from 'react-icons/im';
import { FaChevronDown, FaDownload, FaEye, FaRegCircle } from 'react-icons/fa6';
import { FaRegEdit } from 'react-icons/fa';

const JobDetail = () => {
  const params = useParams();
  const id = parseInt(params.id) - 1;
  const [job, setJob] = useState(jobs[0]);
  const [selected, setSelected] = useState('0');
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    setJob(jobs[id ?? 0]);
    window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
  }, [id]);

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  const handleOutsideClick = (e) => {
    if (e.target.id === 'modalOverlay') {
      setIsModalOpen(false);
    }
  };

  return (
    <JobLayout>
      <div className="container mx-auto">
        <div className="w-full flex flex-col md:flex-row gap-10">
          {/* LEFT SIDE */}
          <div className="w-full h-fit md:w-2/3 2xl:2/4 bg-white px-5 py-10 md:px-10 shadow-md">
            <div className="w-full flex items-center justify-between">
              <div className="w-3/4 flex gap-2">
                {/* <img
                  src={job?.company?.profileUrl}
                  alt={job?.company?.name}
                  className="w-20 h-20 md:w-24 md:h-20 rounded"
                /> */}
                <div className="flex flex-col">
                  <p className="text-xl font-semibold text-gray-600">
                    {job?.jobTitle}
                  </p>
                  <span className="text-base">{job?.location}</span>
                  <span className="text-base text-blue-600">
                    {job?.company?.name}
                  </span>
                  <span className="text-gray-500 text-sm">
                    {moment(job?.createdAt).fromNow()}
                  </span>
                </div>
              </div>
              <div className="">
                <AiOutlineSafetyCertificate className="text-3xl text-blue-500" />
              </div>
            </div>
            <div className="w-full flex flex-wrap md:flex-row gap-2 items-center justify-between my-10">
              <div className="bg-[#F0F8FF] w-40 h-16 rounded-lg flex flex-col items-left px-3 justify-center">
                <span className="text-sm whitespace-nowrap">Job Type</span>
                <p className="text-lg font-semibold text-[#04ADE6]">
                  $ {job?.salary}
                </p>
              </div>
              <div className="bg-[#F0F8FF] w-40 h-16 rounded-lg flex flex-col items-left px-3 justify-center">
                <span className="text-sm whitespace-nowrap">Job Setup</span>
                <p className="text-lg font-semibold text-[#04ADE6]">
                  {job?.jobType}
                </p>
              </div>
              <div className="bg-[#F0F8FF] w-40 h-16 rounded-lg flex flex-col items-left px-3 justify-center">
                <span className="text-sm whitespace-nowrap">
                  Experience Level
                </span>
                <p className="text-lg font-semibold text-[#04ADE6]">
                  {job?.applicants?.length}K
                </p>
              </div>
              <div className="bg-[#F0F8FF] w-40 h-16 rounded-lg flex flex-col items-left px-3 justify-center">
                <span className="text-sm whitespace-nowrap">Salary Offer</span>
                <p className="text-lg font-semibold text-[#04ADE6]">
                  {job?.vacancies}
                  <span className="text-[#5E6368] font-light text-xs">
                    /month
                  </span>
                </p>
              </div>
            </div>
            <div className="my-6">
              {selected === '0' ? (
                <>
                  <p className="text-xl font-medium text-black">
                    Job Description
                  </p>
                  <span className="text-base">{job?.detail[0]?.desc}</span>
                  {job?.detail[0]?.requirement && (
                    <>
                      <p className="text-xl font-semibold mt-8 font-medium text-black">
                        Requirement
                      </p>
                      <span className="text-base">
                        {job?.detail[0]?.requirement}
                      </span>
                    </>
                  )}
                </>
              ) : (
                <>
                  <div className="mb-6 flex flex-col">
                    <p className="text-xl text-blue-600 font-semibold">
                      {job?.company?.name}
                    </p>
                    <span className="text-base">{job?.company?.location}</span>
                    <span className="text-sm">{job?.company?.email}</span>
                  </div>
                  <p className="text-xl font-semibold">About Company</p>
                  <span>{job?.company?.about}</span>
                </>
              )}
            </div>
            <div className="inline">
              <CustomButton
                title="Apply for this position"
                containerStyles="px-20 flex items-center justify-center text-black bg-[#FFDE7F] py-3 outline-none rounded text-base"
                onClick={toggleModal}
              />
            </div>
          </div>
          {/* RIGHT SIDE */}
          <div className="w-full md:w-1/3 2xl:w-1/4 p-5 mt-20 md:mt-0">
            <p className="text-gray-500 font-semibold">Similar Job Post</p>
            <div className="w-full flex flex-wrap gap-4">
              {jobs
                ?.slice(0, 3)
                .map((job, index) => <JobCard job={job} key={index} />)}
            </div>
          </div>
        </div>
      </div>
      {isModalOpen && (
        <div
          id="modalOverlay"
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
          onClick={handleOutsideClick}
        >
          {/* success full message start  */}
          {/* <div
            className="bg-white w-11/12 md:w-2/3 lg:w-1/3 rounded-lg shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-10 text-center ">
              <div className="flex justify-center pb-5">
                <ImCheckmark className="bg-[#43C59E] w-10 h-10 p-2 rounded-full text-white" />
              </div>

              <h2 className="text-base font-xs text-black font-bold mb-2">
                Your application was sent!
              </h2>
              <p className="text-normal mb-3">
                Your application has been successfully submitted.
              </p>
              <div className="w-full flex gap-4">
                <Link to="#" className="w-full border p-1 text-black rounded">
                  <button>Close</button>
                </Link>
                <Link to="#" className="w-full bg-blue text-white p-1 rounded">
                  <button>See more jobs</button>
                </Link>
              </div>
            </div>
          </div> */}
          {/* success full message end */}

          {/* review modal start  */}
          {/* 
          <div
            className="bg-white w-11/12 md:w-2/3 lg:w-1/3 rounded-lg shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-center bg-[#04ADE6] text-white items-center mb-4">
              <h2 className="text-base p-2 font-bold">
                Apply as Contact Center Agent
              </h2>
            </div>

            <div className="relative">
              <div className="px-6">
                <div className="w-full bg-gray-200 h-2 rounded-lg flex justify-center items-center">
                  <div className="w-full h-full bg-blue-500 rounded-lg"></div>
                  <p className="text-xs ml-2">100%</p>
                </div>
              </div>

              <div className="px-6 mt-4">
                <h2 className="text-base font-bold text-black">
                  Profile Review Application
                </h2>
                <p className="text-sm font-light	">
                  The employer will also receive a copy of your profile.
                </p>
              </div>
            </div>
            <form className="p-6">
              <div className="mb-4">
                <hr className="border-t border-gray-300" />
                <h3 className="text-base font-bold mt-4 mb-2 text-black">
                  Contact Information
                </h3>
                <div className="flex items-center mb-4">
                  <img
                    src="https://via.placeholder.com/50"
                    alt="Profile"
                    className="rounded-full mr-4"
                  />
                  <div>
                    <p className="text-base font-semibold text-black">
                      John Doe
                    </p>
                    <p className="text-sm text-gray-500">Software Engineer</p>
                  </div>
                </div>
                <div className="mb-4">
                  <p className="text-sm font-light text-gray-400">Email</p>
                  <p className="text-xs text-black font-normal">
                    john.doe@example.com
                  </p>
                </div>
                <div className="mb-4">
                  <p className="text-sm font-light text-gray-400">
                    Mobile Number
                  </p>
                  <p className="text-xs text-black font-normal	">123-456-7890</p>
                </div>
                <hr className="border-t border-gray-300 my-4" />
                <h3 className="text-base font-bold mb-2 text-black">Resume</h3>
                <div className="border p-2 rounded-lg flex items-center justify-between">
                  <div className="flex items-center">
                    <AiOutlineFilePdf className="text-3xl text-red-500 mr-2" />
                    <div>
                      <p className="text-xs text-black font-normal">
                        Resume.pdf
                      </p>
                      <p className="text-xs font-light text-gray-400">
                        Last used on 26 May 2024
                      </p>
                    </div>
                  </div>
                  <button className="text-black text-xs font-normal flex items-center">
                    <FaEye className="mr-1" /> View
                  </button>
                </div>
                <div className="mb-4 mt-4">
                  <p className="text-xs font-medium	italic text-black">
                    I hereby declare that the above information is true and
                    correct to the best of my knowledge and belief.
                  </p>
                </div>
                <div className="flex justify-end mt-6">
                  <button
                    type="button"
                    className="py-2 px-4 text-black text-sm font-semibold rounded-md mr-2"
                    onClick={toggleModal}
                  >
                    Go Back
                  </button>
                  <button
                    type="submit"
                    className="py-1 px-4 bg-[#04ADE6] text-sm font-semibold text-white rounded-md"
                  >
                    Submit Application
                  </button>
                </div>
              </div>
            </form>
          </div> */}
          {/* review modal end  */}

          {/* upload resume start  */}

          {/* <div
            className="bg-white w-11/12 md:w-2/3 lg:w-1/3 rounded-lg shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-center bg-[#04ADE6] text-white items-center mb-4">
              <h2 className="text-base p-2 font-bold">
                Apply as Contact Center Agent
              </h2>
            </div>

            <div className="relative">
              <div className="px-6">
                <div className="w-full flex items-center">
                  <div className="w-full">
                    <div className="bg-[#E7E6E6] rounded-full h-2.5">
                      <div
                        className="bg-[#04ADE6] h-2.5 rounded-full"
                        style={{ width: '50%' }}
                      />
                    </div>
                  </div>
                  <div className="ml-2">
                    <p className="text-xs">50%</p>
                  </div>
                </div>
              </div>
            </div>
            <form className="p-6">
              <div className="mb-4">
                <h3 className="text-base font-bold mb-2 text-black">Resume</h3>
                <div className="border p-2 rounded-lg flex items-center justify-between mt-1">
                  <div className="flex items-center">
                    <AiOutlineFilePdf className="text-3xl text-red-500 mr-2" />
                    <div>
                      <p className="text-xs text-black font-normal">
                        Resume.pdf
                      </p>
                      <p className="text-xs font-light text-gray-400">
                        Last used on 26 May 2024
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button className="text-black text-xs font-normal flex items-center">
                      <FaDownload className="mr-1" /> Download
                    </button>
                    <button className="text-black text-xs font-normal flex items-center">
                      <FaRegCircle className="mr-1 text-blue w-2 h-2" /> Use
                    </button>
                  </div>
                </div>
                <div className="border p-2 rounded-lg flex items-center justify-between mt-1">
                  <div className="flex items-center">
                    <AiOutlineFilePdf className="text-3xl text-red-500 mr-2" />
                    <div>
                      <p className="text-xs text-black font-normal">
                        Resume.pdf
                      </p>
                      <p className="text-xs font-light text-gray-400">
                        Last used on 26 May 2024
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button className="text-black text-xs font-normal flex items-center">
                      <FaDownload className="mr-1" /> Download
                    </button>
                    <button className="text-black text-xs font-normal flex items-center">
                      <FaRegCircle className="mr-1 text-blue w-2 h-2" /> Use
                    </button>
                  </div>
                </div>

                <div className="flex justify-between items-center space-x-2 mt-4">
                  <button className="bg-[#FFDE7F] text-xs font-semibold  text-black  flex items-center py-1 px-4 rounded ">
                    Upload new résumé
                  </button>
                  <button className="text-blue text-xs font-normal flex items-center py-1 px-3 rounded">
                    Show 2 more résumés <FaChevronDown className="ml-1" />
                  </button>
                </div>
                <p
                  className=" font-thin text-black"
                  style={{ fontSize: '8px' }}
                >
                  doc, docx, and pdf (Max: 2MB) only
                </p>
                <div className="flex justify-end mt-3">
                  <button
                    type="button"
                    className="py-2 px-4 text-black text-sm font-semibold rounded-md mr-2"
                    onClick={toggleModal}
                  >
                    Go Back
                  </button>
                  <button
                    type="submit"
                    className="py-1 px-16 bg-[#04ADE6] text-sm font-semibold text-white rounded-md"
                  >
                    Next
                  </button>
                </div>
              </div>
            </form>
          </div> */}
          {/* upload resume end */}

          {/* beginning of job applity start  */}

          {/* <div
            className="bg-white w-11/12 md:w-2/3 lg:w-1/3 rounded-lg shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-center bg-[#04ADE6] text-white items-center mb-4">
              <h2 className="text-base p-2 font-bold">
                Apply as Contact Center Agent
              </h2>
            </div>

            <div className="relative">
              <div className="px-6">
                <div className="w-full flex items-center">
                  <div className="w-full">
                    <div className="bg-[#E7E6E6] rounded-full h-2.5">
                      <div
                        className="bg-[#04ADE6] h-2.5 rounded-full"
                        style={{ width: '0%' }}
                      />
                    </div>
                  </div>
                  <div className="ml-2">
                    <p className="text-xs">0%</p>
                  </div>
                </div>
              </div>
            </div>
            <form className="p-6">
              <div className="mb-4">
                <h3 className="text-base font-bold mb-2 text-black">
                  Contact Information
                </h3>
                <div className="flex items-center mb-4">
                  <img
                    src="https://via.placeholder.com/50"
                    alt="Profile"
                    className="rounded-full mr-4"
                  />
                  <div>
                    <p className="text-base font-semibold text-black">
                      John Doe
                    </p>
                    <p className="text-sm text-gray-500">Software Engineer</p>
                  </div>
                </div>
                <div className="mb-4">
                  <input
                    type="text"
                    className="mt-1 block w-full p-2  rounded-md shadow-sm focus:ring focus:ring-opacity-50 focus:ring-blue-300 outline-0"
                    style={{ border: '1px solid #E7E6E6' }}
                    placeholder="Your Name"
                  />
                </div>
                <div className="mb-4">
                  <input
                    type="email"
                    className="mt-1 block w-full p-2  rounded-md shadow-sm focus:ring focus:ring-opacity-50 focus:ring-blue-300 outline-0"
                    style={{ border: '1px solid #E7E6E6' }}
                    placeholder="Your Email"
                  />
                </div>

                <div className="flex justify-end mt-3">
                  <button
                    type="button"
                    className="py-2 px-4 text-black text-sm font-semibold rounded-md mr-2"
                    onClick={toggleModal}
                  >
                    Go Back
                  </button>
                  <button
                    type="submit"
                    className="py-1 px-16 bg-[#04ADE6] text-sm font-semibold text-white rounded-md"
                  >
                    Next
                  </button>
                </div>
              </div>
            </form>
          </div> */}
          {/* beginning of job applity end  */}

          {/* share via email start  */}

          <div
            className="bg-white w-11/12 md:w-2/3 lg:w-1/3 rounded-lg shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-center bg-[#04ADE6] text-white items-center mb-4">
              <h2 className="text-base p-2 font-bold">Share via email</h2>
            </div>

            <form className="px-6 py-4">
              <div className="mb-4">
                <div className="mb-4">
                  <label className="block text-base font-semibold text-black">
                    Email
                  </label>
                  <input
                    type="text"
                    className="mt-1 block w-full p-2  rounded-md shadow-sm focus:ring focus:ring-opacity-50 focus:ring-blue-300 outline-0"
                    style={{ border: '1px solid #E7E6E6' }}
                    placeholder="Your Name"
                  />
                </div>
                <div className="w-full flex justify-between mt-7">
                  <button
                    type="button"
                    className="w-full py-2 px-4 text-black text-sm font-semibold border rounded-md mr-2"
                    onClick={toggleModal}
                  >
                    Go Back
                  </button>
                  <button
                    type="submit"
                    className="w-full py-1 px-4 bg-[#04ADE6] text-sm font-semibold text-white rounded-md"
                  >
                    Next
                  </button>
                </div>
              </div>
            </form>
          </div>
          {/* share via email end  */}
        </div>
      )}
    </JobLayout>
  );
};

export default JobDetail;
