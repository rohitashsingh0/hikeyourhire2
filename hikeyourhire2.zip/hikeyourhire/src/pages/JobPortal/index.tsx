import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  MdEdit,
  MdOutlineKeyboardArrowDown,
  MdOutlineKeyboardArrowUp,
} from 'react-icons/md';
import JobLayout from '../../layout/JobLayout';
import JobListings from './JobListings';
import {
  experience,
  jobLocation,
  jobSetup,
  jobTypes,
  jobs,
} from '../../utils/data';
import { BsStars } from 'react-icons/bs';
import { BiBriefcaseAlt2 } from 'react-icons/bi';
import Categories from './Categories';

const JobPortal = () => {
  const [activeTab, setActiveTab] = React.useState('personal');
  const [isEditMode, setIsEditMode] = React.useState(false);

  const toggleEditMode = () => {
    setIsEditMode((prevMode) => !prevMode);
  };

  const [isJobTypeOpen, setIsJobTypeOpen] = React.useState(true);
  const [isExperienceOpen, setIsExperienceOpen] = React.useState(true);
  const [isJobLocationOpen, setIsJobLocationOpen] = React.useState(true);
  const [isJobSetupOpen, setIsJobSetupOpen] = React.useState(true);

  const toggleJobType = () => {
    setIsJobTypeOpen(!isJobTypeOpen);
  };

  const toggleExperience = () => {
    setIsExperienceOpen(!isExperienceOpen);
  };

  const toggleJobLocation = () => {
    setIsJobLocationOpen(!isJobLocationOpen);
  };

  const toggleJobSetup = () => {
    setIsJobSetupOpen(!isJobSetupOpen);
  };

  const [selectedJobTypes, setSelectedJobTypes] = React.useState([]);
  const [selectedExperiences, setSelectedExperiences] = React.useState([]);
  const [selectedJobLocations, setSelectedJobLocations] = React.useState([]);
  const [selectedJobSetups, setSelectedJobSetups] = React.useState([]);

  const handleJobTypeChange = (jobType) => {
    setSelectedJobTypes((prevTypes) =>
      prevTypes.includes(jobType)
        ? prevTypes.filter((type) => type !== jobType)
        : [...prevTypes, jobType],
    );
  };

  const handleExperienceChange = (experience) => {
    setSelectedExperiences((prevExps) =>
      prevExps.includes(experience)
        ? prevExps.filter((exp) => exp !== experience)
        : [...prevExps, experience],
    );
  };

  const handleJobLocationChange = (location) => {
    setSelectedJobLocations((prevLocs) =>
      prevLocs.includes(location)
        ? prevLocs.filter((loc) => loc !== location)
        : [...prevLocs, location],
    );
  };

  const handleJobSetupChange = (setup) => {
    setSelectedJobSetups((prevSetups) =>
      prevSetups.includes(setup)
        ? prevSetups.filter((stp) => stp !== setup)
        : [...prevSetups, setup],
    );
  };

  const [filteredJobs, setFilteredJobs] = React.useState(jobs);

  useEffect(() => {
    let filtered = jobs;

    if (selectedJobTypes.length > 0) {
      filtered = filtered.filter((job) =>
        selectedJobTypes.includes(job.jobType),
      );
    }

    if (selectedExperiences.length > 0) {
      filtered = filtered.filter((job) =>
        selectedExperiences.includes(job.experience),
      );
    }

    if (selectedJobLocations.length > 0) {
      filtered = filtered.filter((job) =>
        selectedJobLocations.includes(job.jobLocation),
      );
    }

    if (selectedJobSetups.length > 0) {
      filtered = filtered.filter((job) =>
        selectedJobSetups.includes(job.jobSetup),
      );
    }

    setFilteredJobs(filtered);
  }, [
    selectedJobTypes,
    selectedExperiences,
    selectedJobLocations,
    selectedJobSetups,
  ]);

  return (
    <JobLayout>
      <div className="wrapper py-5 bg-[#ebf0f9]">
        <div className="container mx-auto sm:px-10">
          <Categories />
          <div className="grid grid-cols-12 gap-8 ">
            <div className="col-span-12 lg:col-span-3 md:col-span-5 min-w-50">
              <div>
                <div className=" flex-col h-fit shadow-sm">
                  <div className="flex justify-between my-4">
                    <p className="text-lg font-semibold text-slate-600">
                      Filters
                    </p>
                    <Link
                      to="#"
                      className="btn rounded  px-10 p-2 font-normal lg:font-medium rounded text-lg bg-white text-[#04ADE6] whitespace-nowrap text-center"
                    >
                      <button className="">Reset</button>
                    </Link>
                  </div>
                  <div className="rounded bg-white shadow-md mb-0 ">
                    <div className="py-2">
                      <div className="flex justify-between p-4">
                        <p className="flex items-center gap-2 font-semibold">
                          <BiBriefcaseAlt2 />
                          Job Type
                        </p>

                        <button onClick={toggleJobType}>
                          {isJobTypeOpen ? (
                            <MdOutlineKeyboardArrowUp />
                          ) : (
                            <MdOutlineKeyboardArrowDown />
                          )}
                        </button>
                      </div>

                      {isJobTypeOpen && (
                        <div className="flex flex-col gap-2 px-4">
                          {jobTypes.map((jtype, index) => (
                            <div
                              key={index}
                              className="flex gap-2 text-sm md:text-base"
                            >
                              <input
                                type="checkbox"
                                value={jtype}
                                className="w-4 h-4"
                                onChange={() => handleJobTypeChange(jtype)}
                              />
                              <span>{jtype}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="">
                      <div className="flex justify-between border-b border-t px-4 py-3">
                        <p className="flex items-center gap-2 font-semibold">
                          <BsStars />
                          Experience
                        </p>

                        <button onClick={toggleExperience}>
                          {isExperienceOpen ? (
                            <MdOutlineKeyboardArrowUp />
                          ) : (
                            <MdOutlineKeyboardArrowDown />
                          )}
                        </button>
                      </div>

                      <div className="flex flex-col gap-2 px-4">
                        {isExperienceOpen && (
                          <div className="flex flex-col gap-2">
                            {experience.map((exp) => (
                              <div key={exp.title} className="flex gap-3">
                                <input
                                  type="checkbox"
                                  value={exp?.value}
                                  className="w-4 h-4"
                                  onChange={() =>
                                    handleExperienceChange(exp.value)
                                  }
                                />
                                <span>{exp.title}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="">
                      <div className="flex justify-between border-b px-4 py-3">
                        <p className="flex items-center gap-2 font-semibold">
                          <BiBriefcaseAlt2 />
                          Job Location
                        </p>

                        <button onClick={toggleJobLocation}>
                          {isJobLocationOpen ? (
                            <MdOutlineKeyboardArrowUp />
                          ) : (
                            <MdOutlineKeyboardArrowDown />
                          )}
                        </button>
                      </div>

                      <div className="flex flex-col gap-2 px-4">
                        {isJobLocationOpen && (
                          <div className="flex flex-col gap-2">
                            {jobLocation.map((loc, index) => (
                              <div
                                key={index}
                                className="flex gap-2 text-sm md:text-base"
                              >
                                <input
                                  type="checkbox"
                                  value={loc}
                                  className="w-4 h-4"
                                  onChange={() => handleJobLocationChange(loc)}
                                />
                                <span>{loc}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="">
                      <div className="flex justify-between mb-3 border-b px-4 py-2">
                        <p className="flex items-center gap-2 font-semibold">
                          <BiBriefcaseAlt2 />
                          Job Setup
                        </p>

                        <button onClick={toggleJobSetup}>
                          {isJobSetupOpen ? (
                            <MdOutlineKeyboardArrowUp />
                          ) : (
                            <MdOutlineKeyboardArrowDown />
                          )}
                        </button>
                      </div>

                      <div className="flex flex-col gap-2 px-4">
                        {isJobSetupOpen && (
                          <div className="flex flex-col gap-2">
                            {jobSetup.map((setup, index) => (
                              <div
                                key={index}
                                className="flex gap-2 text-sm md:text-base"
                              >
                                <input
                                  type="checkbox"
                                  value={setup}
                                  className="w-4 h-4"
                                  onChange={() => handleJobSetupChange(setup)}
                                />
                                <span>{setup}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-span-12 lg:col-span-9 md:col-span-7 ">
              <div className="rounded">
                <JobListings jobs={filteredJobs} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </JobLayout>
  );
};

export default JobPortal;
