import React from 'react';
import { BRAND } from '../../../types/brand';
import BrandOne from '/assets/admin/brand/brand-01.svg';
import BrandTwo from '/assets/admin/brand/brand-02.svg';
import BrandThree from '/assets/admin/brand/brand-03.svg';
import BrandFour from '/assets/admin/brand/brand-04.svg';
import BrandFive from '/assets/admin/brand/brand-05.svg';
import { BsThreeDots } from 'react-icons/bs';

const brandData: BRAND[] = [
  {
    logo: BrandOne,
    name: 'Google',
    visitors: 3.5,
    revenues: '5,768',
    sales: 590,
    conversion: 4.8,
  },
  {
    logo: BrandTwo,
    name: 'Twitter',
    visitors: 2.2,
    revenues: '4,635',
    sales: 467,
    conversion: 4.3,
  },
  {
    logo: BrandThree,
    name: 'Github',
    visitors: 2.1,
    revenues: '4,290',
    sales: 420,
    conversion: 3.7,
  },
  {
    logo: BrandFour,
    name: 'Vimeo',
    visitors: 1.5,
    revenues: '3,580',
    sales: 389,
    conversion: 2.5,
  },
  {
    logo: BrandFive,
    name: 'Facebook',
    visitors: 3.5,
    revenues: '6,768',
    sales: 390,
    conversion: 4.2,
  },
];

const TableOne = () => {
  const [selectedBrand, setSelectedBrand] = React.useState<BRAND | null>(null);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  const handleDropdown = (brand: BRAND) => {
    if (selectedBrand === brand) {
      setSelectedBrand(null); // Hide dropdown if same brand is clicked again
    } else {
      setSelectedBrand(brand);
    }
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (
      dropdownRef.current &&
      !dropdownRef.current.contains(event.target as Node)
    ) {
      setSelectedBrand(null); // Hide dropdown when clicking outside
    }
  };

  React.useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="rounded-2xl border border-stroke bg-white px-5 pt-6 pb-2.5 shadow-default dark:border-strokedark dark:bg-boxdark sm:px-7.5 xl:pb-1 overflow-x-auto">
      <h4 className="mb-6 text-xl font-semibold text-black dark:text-white">
        Recent Applications
      </h4>
      <div className="min-w-full overflow-x-auto">
        <div className="grid grid-cols-5 gap-4 rounded-sm bg-gray-2 dark:bg-meta-4 min-w-[800px]">
          <div className="p-2.5 xl:p-5">
            <h5 className="text-sm font-medium uppercase text-black xsm:text-base">
              Full Name
            </h5>
          </div>
          <div className="p-2.5 text-center xl:p-5">
            <h5 className="text-sm font-medium uppercase text-black  xsm:text-base">
              Position
            </h5>
          </div>
          <div className="p-2.5 text-center xl:p-5">
            <h5 className="text-sm font-medium uppercase text-black  xsm:text-base">
              Stage
            </h5>
          </div>
          <div className="p-2.5 text-center xl:p-5">
            <h5 className="text-sm font-medium uppercase text-black  xsm:text-base">
              Location
            </h5>
          </div>
          <div className="p-2.5 text-center xl:p-5">
            <h5 className="text-sm font-medium uppercase text-black  xsm:text-base">
              Actions
            </h5>
          </div>
        </div>

        {brandData.map((brand, key) => (
          <div
            className={`grid grid-cols-5 gap-4 min-w-[800px] ${
              key % 2 === 0
                ? 'bg-white dark:bg-gray-800'
                : 'bg-gray-2 dark:bg-gray-700'
            } ${
              key === brandData.length - 1
                ? ''
                : 'border-b border-stroke dark:border-strokedark'
            }`}
            key={key}
          >
            <div className="flex items-center gap-3 p-2.5 xl:p-5">
              <p className="text-black dark:text-white">{brand.name}</p>
            </div>

            <div className="flex items-center justify-center p-2.5 xl:p-5">
              <p className="text-black dark:text-white">{brand.visitors}K</p>
            </div>

            <div className="flex items-center justify-center p-2.5 xl:p-5">
              <p className="text-meta-3">${brand.revenues}</p>
            </div>

            <div className="flex items-center justify-center p-2.5 xl:p-5">
              <p className="text-black dark:text-white">{brand.sales}</p>
            </div>

            <div className="flex items-center justify-center p-2.5 xl:p-5">
              <div className="relative inline-block text-left">
                <button
                  type="button"
                  onClick={() => handleDropdown(brand)}
                  className="text-black dark:text-white focus:outline-none"
                >
                  <BsThreeDots className="w-6 h-6" />
                </button>
                {selectedBrand === brand && (
                  <div className="origin-top-right absolute right-0 bg-white z-50">
                    <div
                      className="py-1"
                      role="menu"
                      aria-orientation="vertical"
                      aria-labelledby="options-menu"
                    >
                      <div
                        id="dropdown"
                        className="z-50 bg-white divide-y divide-gray-100 rounded-lg shadow-xl w-44 dark:bg-gray-700"
                      >
                        <ul
                          className=" text-sm text-gray-700 dark:text-gray-200"
                          aria-labelledby="dropdownDefaultButton"
                        >
                          <li>
                            <a
                              href="#"
                              className="block px-4 py-2 hover:bg-gray dark:hover:bg-gray-600 dark:hover:text-white"
                            >
                              View
                            </a>
                          </li>
                          <li>
                            <a
                              href="#"
                              className="block px-4 py-2 hover:bg-gray dark:hover:bg-gray-600 dark:hover:text-white"
                            >
                              Edit
                            </a>
                          </li>
                          <li>
                            <a
                              href="#"
                              className="block px-4 py-2 hover:bg-gray dark:hover:bg-gray-600 dark:hover:text-white"
                            >
                              Deactivate
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TableOne;
