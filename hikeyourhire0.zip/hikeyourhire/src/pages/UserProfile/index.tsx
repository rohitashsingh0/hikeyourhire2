import React from 'react';
import './style.css';
import ProfileLayout from '../../layout/ProfileLayout';
import { Link } from 'react-router-dom';

const UserProfile = () => {
  const [activeTab, setActiveTab] = React.useState('personal');
  const [isEditMode, setIsEditMode] = React.useState(false);

  const toggleEditMode = () => {
    setIsEditMode((prevMode) => !prevMode);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'personal':
        return (
          <>
            <div className="mt-3 mb-2 text-sm font-medium basic-info-text">
              Basic Information
            </div>
            <div className="overflow-x-auto">
              <table className="table basic-info table-borderless">
                <thead>
                  <tr>
                    <th scope="col">Last Name</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Middle Name</th>
                    <th scope="col">Preferred Name</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      {isEditMode ? (
                        <input type="text" defaultValue="Doe" />
                      ) : (
                        'Doe'
                      )}
                    </td>
                    <td>
                      {isEditMode ? (
                        <input type="text" defaultValue="John" />
                      ) : (
                        'John'
                      )}
                    </td>
                    <td>
                      {isEditMode ? (
                        <input type="text" defaultValue="N/A" />
                      ) : (
                        'N/A'
                      )}
                    </td>
                    <td>
                      {isEditMode ? (
                        <input type="text" defaultValue="Joe" />
                      ) : (
                        'Joe'
                      )}
                    </td>
                  </tr>
                  <tr>
                    <th>Gender</th>
                    <th>Marital Status</th>
                    <th>Citizenship</th>
                  </tr>
                  <tr>
                    <td>
                      {isEditMode ? (
                        <input type="text" defaultValue="Male" />
                      ) : (
                        'Male'
                      )}
                    </td>
                    <td>
                      {isEditMode ? (
                        <input type="text" defaultValue="Single" />
                      ) : (
                        'Single'
                      )}
                    </td>
                    <td>
                      {isEditMode ? (
                        <input type="text" defaultValue="U.S." />
                      ) : (
                        'U.S.'
                      )}
                    </td>
                  </tr>
                  <tr>
                    <th>Birthday</th>
                    <th>Age</th>
                    <th colSpan="2">
                      Have you been a previous employee of TBPO?
                      {isEditMode ? (
                        <input type="text" defaultValue="no" />
                      ) : (
                        'no'
                      )}
                    </th>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" defaultValue="December 02, 1995" />
                    </td>
                    <td>
                      <input type="text" defaultValue="27 years" />
                    </td>
                    <td colSpan="2">
                      <input type="text" defaultValue="no" />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="overflow-x-auto">
              <table className="mt-12 table table-borderless basic-info">
                <thead className="d-flex">
                  <tr>
                    <th>Address</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Complete Address</th>
                  </tr>
                  <tr>
                    <td colSpan="4">
                      <input
                        type="text"
                        defaultValue="BLK208 L26 Manchester Street, Grand Broadmore, Antel Grand Village"
                      />
                    </td>
                  </tr>
                  <tr>
                    <th>City/municipality</th>
                    <th>Province</th>
                    <th>Zip/Postal Code</th>
                    <th>Country</th>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" defaultValue="General Trias" />
                    </td>
                    <td>
                      <input type="text" defaultValue="Cavite" />
                    </td>
                    <td>
                      <input type="text" defaultValue="4107" />
                    </td>
                    <td>
                      <input type="text" defaultValue="Philippines" />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="overflow-x-auto">
              <table className="mt-12 table table-borderless basic-info">
                <thead className="d-flex">
                  <tr>
                    <th>Address</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Mobile</th>
                    <th>Landline</th>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" defaultValue="+63 917 813 9805" />
                    </td>
                    <td>
                      <input type="text" defaultValue="+63 2 046 417 0259" />
                    </td>
                  </tr>
                  <tr>
                    <th>Mobile</th>
                    <th>Landline</th>
                    <th>Relationship</th>
                  </tr>
                  <tr>
                    <td>
                      <input type="text" defaultValue="+63 917 813 9805" />
                    </td>
                    <td>
                      <input type="text" defaultValue="+63 2 046 417 0259" />
                    </td>
                    <td>
                      <input type="text" defaultValue="Spouse" />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </>
        );

      case 'education':
        return (
          <div className="mt-3 mb-2 text-sm font-medium basic-info-text">
            Education
            <div className="overflow-x-auto">
              <table className="mt-12 table table-borderless basic-info">
                {/* Education content */}
              </table>
            </div>
          </div>
        );
      case 'ids':
        return (
          <div className="mt-3 mb-2 text-sm font-medium basic-info-text">
            IDs
            <div className="overflow-x-auto">
              <table className="mt-12 table table-borderless basic-info">
                {/* IDs content */}
              </table>
            </div>
          </div>
        );
      case 'social':
        return (
          <div className="mt-3 mb-2 text-sm font-medium basic-info-text">
            Social
            <div className="overflow-x-auto">
              <table className="mt-12 table table-borderless basic-info">
                {/* Social content */}
              </table>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <ProfileLayout>
      <div className="wrapper py-15 bg-[#ebf0f9]">
        <div className="container">
          <div className="row">
            <div className="col-lg-3">
              <div className="card mb-4 shadow-md ">
                <div className="card-body  text-center">
                  <img
                    src="https://img.freepik.com/free-vector/blue-circle-with-white-user_78370-4707.jpg?size=626&ext=jpg"
                    alt="profile-img"
                    className="w-32 h-32 mx-auto rounded-full dark:bg-gray-500 aspect-square"
                  />
                  <h2>John</h2>
                  <p>john@1233gmail.com</p>
                  <button className="btn btn-primary" onClick={toggleEditMode}>
                    Edit Profile
                  </button>
                </div>
              </div>
              <div className="card mb-4 shadow-md ">
                <div className="card-body">
                  <div className="title flex justify-center items-center">
                    <h3>Work Experience</h3>{' '}
                    <span className="flex justify-center items-center mx-auto m-auto ">
                      <img
                        src="https://cdn-icons-png.flaticon.com/512/1250/1250222.png"
                        alt="user"
                      />
                    </span>
                  </div>
                  <ul>
                    <li>
                      <h4>Senior Web Developer</h4>
                      <p>2 months</p>
                    </li>
                    <li>
                      <h4>Junior Web Developer</h4>
                      <p>5 years</p>
                    </li>
                    <li>
                      <h4>Website Developer</h4>
                      <p>6 months</p>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="card mb-4 shadow-md ">
                <div className="card-body">
                  <div className="title">
                    <h3>Recently Applied Jobs</h3>
                    <i className="fa-solid fa-arrow-up-right-from-square" />
                  </div>
                  <ul>
                    <li>
                      <h4>Enterprices Software de...</h4>
                      <Link to="#">View</Link>
                    </li>
                    <li>
                      <h4>IT Manager</h4>
                      <Link to="#">View</Link>
                    </li>
                    <li>
                      <h4>UI/UX Researcher</h4>
                      <Link to="#">View</Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="card  shadow-md ">
                <button className="btn btn-primary dwnd">
                  {' '}
                  Download Resume
                  <i className="fa-solid fa-download" />
                </button>
              </div>
            </div>
            <div className="col-lg-9">
              <div className="card shadow-md ">
                <div className="card-body">
                  <ul className="nav nav-underline border-bottom tabs">
                    <li className="nav-item mr-10">
                      <button
                        className={`nav-link ${
                          activeTab === 'personal' ? 'active' : ''
                        }`}
                        onClick={() => setActiveTab('personal')}
                        aria-current="page"
                      >
                        Personal Details
                      </button>
                    </li>
                    <li className="nav-item mr-10">
                      <button
                        className={`nav-link ${
                          activeTab === 'education' ? 'active' : ''
                        }`}
                        onClick={() => setActiveTab('education')}
                      >
                        Education
                      </button>
                    </li>
                    <li className="nav-item mr-10">
                      <button
                        className={`nav-link ${
                          activeTab === 'ids' ? 'active' : ''
                        }`}
                        onClick={() => setActiveTab('ids')}
                      >
                        IDs
                      </button>
                    </li>
                    <li className="nav-item mr-10">
                      <button
                        className={`btn nav-link ${
                          activeTab === 'social' ? 'active' : ''
                        }`}
                        onClick={() => setActiveTab('social')}
                      >
                        Social
                      </button>
                    </li>
                  </ul>

                  {/* Render content based on active tab */}
                  {renderContent()}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ProfileLayout>
  );
};

export default UserProfile;
